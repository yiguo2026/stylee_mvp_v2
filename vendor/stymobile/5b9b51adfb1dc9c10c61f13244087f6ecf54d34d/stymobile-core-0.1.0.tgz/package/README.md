# @stymobile/core

提供createAccountScope、runScopedRead、runScopedCommand和chooseEntityVersion。
只管理纯内存范围与准入；不包含Auth SDK、平台文件/图片缓存、网络、重试或Store实现。
resetter、read apply/onError和command apply必须同步；stamp不可序列化复用。
runScopedRead只裁定当前读取能否进入本地状态，不伪造命令回执；所有后续写需重新准入。
server授权、operation幂等、具体Store接入和Native验证仍是独立门槛。
