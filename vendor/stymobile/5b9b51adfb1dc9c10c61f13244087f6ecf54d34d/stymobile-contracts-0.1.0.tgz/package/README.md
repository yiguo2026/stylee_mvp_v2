# @stymobile/contracts

提供App-owned schema_version=1命令DTO及commandRecovery恢复意图。
这是类型合同，不是任意JSON的运行时验证器；输入须由api-client验证。
标识不生成、请求不发送、恢复意图不自动执行；不裁定用户扣次。
包仍private/0.1.0/UNLICENSED；它只与同批Core tarball消费，尚未发布到registry。
