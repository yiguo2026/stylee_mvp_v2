# @stymobile/contracts

提供App-owned schema_version=1命令DTO及commandRecovery恢复意图。
这是类型合同，不是任意JSON的运行时验证器；输入须由api-client验证。
标识不生成、请求不发送、恢复意图不自动执行；不裁定用户扣次。
包仍private/UNLICENSED；新增版本化风格偏好合同后，与同批Core一起升为0.3.0，api-client为0.2.0并精确依赖两包0.3.0。尚未发布到registry；已封装的旧Web0.1.0 tarball保持不变。

`STYLE_PREFERENCE_CATALOG_VERSION`固定为`stylee-style-v1`；
`STYLE_PREFERENCE_V1_OPTIONS`按批准顺序记录19项tagId/displayName/modelValue/sortOrder，数组与每项均冻结。
这是合同fixture/source manifest及离线UI回退，不是另一份可独立编辑的运行时目录；服务端回读必须与该版本匹配后才能启用保存。

偏好snapshot、selection、option、replace payload及controller snapshot均为readonly声明，不包含provider/session材料。
`unseen`与`revision=null`表示尚无aggregate；写入payload只表达`selected`或`skipped`。
这些类型不实现JSON校验、Core aggregate、RPC、controller或Mobile页面；运行时校验和保存规则由后续任务实现。
