# @stymobile/core

提供createAccountScope、runScopedRead、runScopedCommand、chooseEntityVersion和风格偏好 aggregate/draft 纯函数。
只管理纯内存范围与准入；不包含Auth SDK、平台文件/图片缓存、网络、重试或Store实现。
resetter、read apply/onError和command apply必须同步；stamp不可序列化复用。
runScopedRead只裁定当前读取能否进入本地状态，不伪造命令回执；所有后续写需重新准入。
server授权、operation幂等、具体Store接入和Native验证仍是独立门槛。
风格偏好以`style-preferences`为稳定实体键；只有selected/skipped快照参与正整数revision裁决，unseen不构成revision实体。selected读取至少含一项；非legacy项必须存在于本次active options，真实历史正向选择可全部为`legacy=true`。这只放宽服务端read admission，不放宽v1写入；草稿仍仅可加入服务端当前目录项，当前已选legacy项只可保留或移除，全部结果为冻结副本且最多40项。
