# @stymobile/api-client

Private0.2.1 shared Auth and style-preference controllers and provider adapters. Exact dependencies: `@stymobile/contracts@0.3.0` and `@stymobile/core@0.3.0`. The version bump keeps the previously packed api-client0.2.0 and Web0.1.0 artifacts immutable. No React, Native, Mobile or Supabase runtime/type dependency is shipped here.

## Controller API for Mobile and Web

```ts
import { createAuthController, createSupabaseAuthPort } from '@stymobile/api-client';
import { createAccountScope } from '@stymobile/core';
const port = createSupabaseAuthPort({ client, recoveryClient });
const auth = createAuthController({ port, scope: createAccountScope(), now: Date.now });
```

`getSnapshot(): AuthSnapshot` and `subscribe(listener: () => void): () => void` implement a stable external-store surface. Snapshot and profile are frozen copies; snapshots contain only phase, busy, email, profile, profileStatus, message and retryAt. Import `AuthSnapshot`, `AuthProfile`, `AuthPhase`, `AuthMessage` from contracts. Message is a fixed union, not provider prose. `retryAt` uses the injected clock in milliseconds.

All user actions return `Promise<void>` and publish their outcome in the snapshot:

- `start()` restores only after server validation; can retry a bootstrap failure.
- `signIn({ identity, password, mode: 'email' | 'legacy_username' })` accepts existing passwords without the new-password minimum; legacy uppercase escapes match historical registration exactly and never fall back to a lowercased alias. Legacy input accepts historical letters, digits, underscore only.
  An unconfirmed email login resumes `awaiting_verification` after successful cleanup, with the submitted email and `retryAt:0`; no email is automatically sent. Legacy login, cancelled operations and cleanup failures do not enter this flow.
- `register({ email, password, confirmation, nickname })` creates an awaiting-verification flow. New password minimum8; nickname optional as empty string, maximum40 Unicode code points, matching the backend trigger. A send response does not prove mailbox ownership or mail delivery.
- `verifySignup(code)` uses signup-purpose OTP; `resendSignup()` respects60 seconds from the previous send attempt, including unknown outcomes.
- `requestRecovery(email)` begins or resends recovery with60-second cooldown; `verifyRecovery(code)` requires a6-digit recovery OTP; `resetPassword(password, confirmation)` requires that recovery authorization. Success clears recovery and returns to normal login. Unknown password outcome is `password_update_unknown`; no automatic replay.
- `cancelFlow()` and `signOut()` immediately revoke Core/UI admission, wait for active controller work, and then clear both clients. Failure remains blocked with `cleanup_failed`; only an explicit cleanup retry can reopen admission.
- `retryProfile()` retries only the authenticated owner's profile. `missing` and `failed` stay distinct; neither creates a row.
- `dispose(): void` synchronously revokes admission and unsubscribes. Idle authenticated/read-only bootstrap disposal preserves persisted login. Disposal while a user mutation/recovery is outstanding drains and clears its late session effects.
- `whenIdle(): Promise<void>` waits for controller work and cleanup; rejects `AuthPortError('cleanup_failed')` if cleanup was not confirmed. A replacement runtime must not begin after that rejection.

Only `phase === 'authenticated'` admits private routes. Registration/recovery/reset phases never populate AccountScope. Use one controller per owned runtime; actions are single-flight and guarded by an operation generation. Same-account explicit login creates a new Core epoch; normal refresh preserves the stamp. Provider callbacks only schedule processing and never await/query/navigate inside the callback.

Terminal provider events (`signed_out` / `invalid_session`) are bound to the AccountScope stamp or anonymous epoch captured when received. A later profile-read flight cannot discard them; an event for a prior scope cannot revoke a newly admitted account. Registration rechecks its operation after publishing the verification phase, so a synchronous subscriber cancellation/disposal prevents the subsequent provider write.

## Style-preference controller

`createSupabaseStylePreferencePort(client)` accepts only a shallow structural client with `rpc(...)`; the package neither imports nor exposes Supabase SDK types. It calls `get_style_preferences_v1`, `replace_style_preferences_v1`, and `get_style_preference_operation_v1`, preserving the client's method receiver. The adapter decodes snake_case DTOs field by field, requires exact own fields (including the standard optional Supabase `count/status/statusText` wrapper metadata), the exact ordered 19-option `stylee-style-v1` catalog, valid snapshot/command-result semantics, and frozen defensive copies. Extra or inherited required/optional fields fail closed. Provider errors and malformed DTOs collapse to `StylePreferencePortError('preference_unavailable')`; raw SQL/provider prose is never returned.

`createStylePreferenceController({ port, pendingStore, scope, createOperationId })` is a retained external store. Its frozen snapshot contains only `phase`, `server`, `draftTagIds`, `message`, and `busy`. Subscribers run synchronously and cannot reenter an asynchronous action. All public actions are single-flight and bound to an `AccountStamp`; reset/dispose synchronously invalidate outstanding work, and `whenIdle()` drains late work without allowing it to publish.

Before any replace RPC, the controller requires `createOperationId()` to return a canonical lower-case UUID v4, then writes a frozen `PendingPreferenceRecord` containing only `accountId`, `operationId`, `expectedRevision`, and the canonical payload. Invalid generator output or a thrown generator fails with `preference_save_failed` before storage or provider dispatch, without exposing raw prose. Pending-store reads/writes/removes are serialized per account across reset and same-account reauthentication generations. A stale resolved write removes itself before a later store operation; an older remove completes before a later descriptor can be retained. `whenIdle()` drains these current and stale queues. A storage-write failure dispatches no provider write. A lost transport result remains `confirming` and may only query the same operation; a server `retry_same` reuses the stored operation ID and payload. The controller never invents a second operation automatically. Confirmed success requires the stamped owner, matching operation, a revision above the persisted/current revision, and an exact status/sorted-ID match to the pending payload before cleanup. A mismatched successful DTO remains same-operation `confirming`. Fixed failures also remove the descriptor; cleanup rejection stays `confirming`, blocks new writes, and retries same-operation confirmation/cleanup with `preference_save_unknown`, never false success.

Revision conflict handling records an explicit reload fence and the exact canonical pending payload before cleanup/read. Conflict is read-only: `toggle()` is inert, so an empty draft is exactly a pending skip and a nonempty draft is exactly a pending selected write. A failed, stale, or below-conflict owner read remains `conflict`, preserves that pending intent, and blocks save/skip/overwrite; `load()` retries that owner read. Only a Core-accepted snapshot whose revision is at least the conflict result revision enables `confirmConflictOverwrite()`, which generates one new operation against the admitted latest revision. Legacy IDs no longer present in the latest server snapshot are filtered by the existing allowed-draft rule at explicit overwrite; UI consumers must disclose that loss rather than imply restoration. `skip()` persists `status:'skipped'` with an empty selection. Cold `load()` only recovers an exact pending record with a canonical lower-case UUID v4 for the captured account. Any rejected non-null pending value is owner-aware removed before the ordinary server read; cleanup failure returns `preference_read_failed`, dispatches no preference RPC, and remains retryable through an explicit later `load()`. Platform code owns the durable pending-store implementation and the cryptographic operation-ID generator; this package intentionally adds no storage, UI, network, or platform dependency.

## Exact provider boundary

`AuthPort` is exported from `auth-port.ts` and has these methods:

```ts
readSession(): Promise<AuthIdentity | null>;
subscribe(listener: (event: AuthEvent) => void): () => void;
signIn(input: { email: string; password: string }): Promise<AuthIdentity>;
register(input: { email: string; password: string; nickname: string }): Promise<void>;
verifySignup(input: { email: string; code: string }): Promise<AuthIdentity>;
resendSignup(email: string): Promise<void>;
requestRecovery(email: string): Promise<void>;
verifyRecovery(input: { email: string; code: string }): Promise<AuthIdentity>;
resetPassword(password: string, isCurrent: () => boolean): Promise<void>;
clearRecovery(): Promise<void>;
signOut(): Promise<void>;
readProfile(accountId: string): Promise<AuthProfile | null>;
```

`AuthIdentity = Readonly<{ accountId: string; email: string; emailConfirmed: boolean }>` is nonsecret. `AuthEvent` is `{type:'refreshed'|'session_changed',identity}` or `{type:'signed_out'|'invalid_session'}`. Adapter errors are `AuthPortError` with allowlisted codes; raw errors/DTOs are never forwarded.

The internal `AuthPort.resetPassword` requires the controller's operation guard. The adapter checks it on entry and again after asynchronous recovery-session preflight, immediately before `updateUser`; a false guard resolves without dispatching a password write. There is no await between the final guard and provider dispatch. Alternate AuthPort implementations must honor the same rule before any later write after an await. The UI controller signature remains `resetPassword(password, confirmation)`. Cancel/dispose during preflight prevents a not-yet-sent update; it cannot cancel or undo an update already dispatched.

`SupabasePortOptions = Readonly<{ client: SupabaseProfileClient; recoveryClient: SupabaseAuthClient }>`; exact structural declarations live in `src/supabase-auth-types.ts` and the packed `.d.ts`. Main client requires Auth methods plus `from('users'): unknown`. Each query-builder step (`select`, owner-filtered `eq`, `maybeSingle`) is runtime checked and keeps its method receiver. Unknown builder output avoids recursively instantiating PostgREST generic types when a real Supabase2.110.0 client is injected. All provider DTOs are unknown at this boundary and validated before use.

Main client: persistent secure storage, URL detection disabled, SDK debug disabled. Recovery client: a distinct SDK/Auth instance with `persistSession:false`, `autoRefreshToken:false`, `detectSessionInUrl:false`, no secure/persistent storage adapter and SDK debug disabled. Both clients remain owned by the platform runtime. Do not expose them or their session material to routes, snapshots, logs, Core, or URL parameters.

Bootstrap calls `getSession` then server `getUser`, checks account and email match, and derives confirmation only from server `email_confirmed_at`. Signup uses `signUp`, `resend({type:'signup'})`, `verifyOtp({type:'signup'})`. Recovery uses the separate client's `resetPasswordForEmail`, `verifyOtp({type:'recovery'})`, and `updateUser`; password writes are owner-bound to the verified recovery identity. Cleanup uses `signOut({scope:'local'})` and confirms no remaining session. Profile reads only `users.user_id,nickname,gender`, filtered by `user_id`, and verifies returned owner again.

## Platform lifecycle and transport obligations

`whenIdle` fences only controller-owned operations. It does not prove server-side request completion after a lost response or abort, nor undo a submitted password update. Supabase independent auto-refresh/storage work needs separate lifecycle/transport ownership, or a retained runtime across StrictMode remounts. Never create replacement persistent clients while old writes can still reach the same vault. Platform storage failures must reject visibly; no plaintext fallback. Keep singleton listener ownership and dispose explicitly at runtime shutdown.

This package does not implement HTTP transport. Inject a bounded, sanitized fetch into both SDK clients: auth-js2.110.0 logs thrown fetch errors itself, so transport rejection must contain only a fixed safe error without URL, headers, request body or cause. Aborting HTTP does not establish whether a remote write committed; no automatic Auth write retries or conversion of timeout to success. The platform must test that boundary and drain or quarantine outstanding HTTP/storage work before replacing clients.

Mobile explicitly injects SDK55 `expo/fetch` into the shared native wrapper for both clients. That wrapper forces `redirect:'error'` at transport dispatch, after caller options, before any redirect can forward an Auth body. Do not rely on a response-URL check after forwarding or on React Native global fetch's redirect handling. The Node307 regression checks the wrapper using Node fetch, not native iOS/Android execution; the maintained local Auth integration uses the same wrapper policy without an extra test-only redirect restriction.

## Verification

Focused auth tests use real Core AccountScope, deferred operations, complete synthetic provider DTOs and mutable provider session fixtures. `tests/types/auth.ts` checks public declarations and token exclusion. The external tarball consumer (`tests/fixtures/core-consumer.mjs/.ts`) actually logs in/out through the controller without installing Mobile or Supabase. Task4 still must characterize signup OTP against real local Auth; synthetic tests are not mail delivery, production compatibility or device acceptance.
